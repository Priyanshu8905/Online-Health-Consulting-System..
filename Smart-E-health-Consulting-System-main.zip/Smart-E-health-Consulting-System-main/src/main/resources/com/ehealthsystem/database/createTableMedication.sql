CREATE TABLE medication
(
    medication_id   VARCHAR(3),
    medication_name TEXT,
    PRIMARY KEY (medication_id)
);