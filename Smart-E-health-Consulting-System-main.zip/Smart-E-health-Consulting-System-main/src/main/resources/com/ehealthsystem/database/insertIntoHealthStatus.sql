INSERT INTO health_status VALUES
(2, 'M5450', 1),
(2, 'M5459', 2);

