INSERT INTO medication(medication_id, medication_name) VALUES
(1, 'Lisinopril'),
(2, 'Atorvastatin'),
(3, 'Metoprolol');
