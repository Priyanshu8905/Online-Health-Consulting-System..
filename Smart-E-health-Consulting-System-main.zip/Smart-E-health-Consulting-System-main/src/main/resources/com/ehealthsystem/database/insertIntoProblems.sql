INSERT INTO problems VALUES
(1, "Flu (common cold)"),
(2, "Headache"),
(3, "Vaccination against COVID-19"),
(4, "Toothaches"),
(5, "Problems regarding braces"),
(6, "Removal of wisdom teeth"),
(7, "Determine vision (visual acuity)"),
(8, "Heartache"),
(9, "Sports injury"),
(10, "Burning eyes");
