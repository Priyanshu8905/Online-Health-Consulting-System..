INSERT INTO suitableSpecializations VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 3),
(5, 4),
(6, 5),
(7, 6),
(8, 7),
(9, 8),
(10, 6);