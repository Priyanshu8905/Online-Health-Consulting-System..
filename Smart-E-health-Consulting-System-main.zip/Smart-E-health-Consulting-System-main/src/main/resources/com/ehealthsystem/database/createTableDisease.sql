CREATE TABLE disease
(
    ICD             TEXT,
    disease_name    TEXT,
    PRIMARY KEY(ICD)
);