CREATE TABLE location
(
    location_id     INTEGER,
    zip             TEXT,
    city            TEXT,
    PRIMARY KEY (location_id AUTOINCREMENT)
);