INSERT INTO category(category_id,category) VALUES
(1, "General Practitioner"),
(2, "Vaccination Center"),
(3, "Dentist"),
(4, "Orthodontist"),
(5, "Oral Surgeon"),
(6, "Oculist"),
(7, "Cardiologist"),
(8, "Sports Physician");
