CREATE TABLE category
(
    category_id     INTEGER,
    category        TEXT,
    PRIMARY KEY (category_id)
);