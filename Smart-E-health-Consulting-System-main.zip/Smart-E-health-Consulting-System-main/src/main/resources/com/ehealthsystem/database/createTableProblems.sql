CREATE TABLE "problems" (
	"id"	INTEGER,
	"name"	TEXT,
    PRIMARY KEY("id" AUTOINCREMENT)
);
